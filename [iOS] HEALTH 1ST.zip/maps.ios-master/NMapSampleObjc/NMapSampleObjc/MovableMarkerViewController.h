//
//  MovableMarkerViewController.h
//  NMapSampleObjc
//
//  Created by Naver on 2016. 11. 21..
//  Copyright © 2016년 Naver. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <NMapViewerSDK/NMapViewerSDK.h>

@interface MovableMarkerViewController : UIViewController<NMapViewDelegate, NMapPOIdataOverlayDelegate>

@end
