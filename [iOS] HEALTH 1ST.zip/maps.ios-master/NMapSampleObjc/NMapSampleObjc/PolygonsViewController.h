//
//  PolygonsViewController.h
//  NMapSampleObjc
//
//  Created by Naver on 2016. 11. 16..
//  Copyright © 2016년 Naver. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <NMapViewerSDK/NMapViewerSDK.h>

@interface PolygonsViewController : UIViewController<NMapViewDelegate, NMapPOIdataOverlayDelegate>

@end
