//
//  PublicData.swift
//  Health1st
//
//  Created by 양창엽 on 2017. 11. 17..
//  Copyright © 2017년 Yang-Chang-Yeop. All rights reserved.
//

import Foundation

class PublicData
{
    /* MARK - : String */
    public static let SHREAD_PATIENT_PHONE:String = "PHONE"
    public static let NAVER_CLIENT_MAP_ID:String = "4lPxldPbr624tv7_NNXA"
    public static let NAVER_MARKER_TITLE:String = "PATIENT TRACE"
}
