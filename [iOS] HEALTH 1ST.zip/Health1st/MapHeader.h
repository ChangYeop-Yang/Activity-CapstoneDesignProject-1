#ifndef MapHeader
#define MapHeader

#import <NMapViewerSDK/NMapView.h>
#import <NMapViewerSDK/NMapLocationManager.h>

#endif
