package com.health1st.yeop9657.health1st.Accessory;

/**
 * Created by yeop on 2017. 10. 29..
 */

public class SamsungSensorManager {
}
